﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web;
using System.IO;
using System.Net;

namespace unitTests
{
    [TestClass]
    public class module
    {
        [TestMethod]
        public void GETTestMethod()
        {
            //what expected to see coming in
            string expected = "<html><body><h1>Module Response</h1><p>This is the response from the httphandler written for /module/ path</P></body></html>";

            //URI to test
            string uri = "http://fostvm.fost.plymouth.ac.uk/modules/soft338/slongville/module";

            //create web request object
            var webRequest = (HttpWebRequest)WebRequest.Create(uri);
            //set http method
            webRequest.Method = "GET";

            HttpWebResponse response = (HttpWebResponse)webRequest.GetResponse();
            Stream responseStream = response.GetResponseStream();
            StreamReader reader = new StreamReader(responseStream);
            string actual = reader.ReadToEnd();

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void POSTTestMethod()
        {
            //what expected to see coming in
            string expected = "<html><body><h1>Course Response</h1><p>This is the response from the httphandler written for /module/ path</P></body></html>";

            //URI to test
            string uri = "http://fostvm.fost.plymouth.ac.uk/modules/soft338/slongville/module";

            //create web request object
            var webRequest = (HttpWebRequest)WebRequest.Create(uri);
            //set http method
            webRequest.Method = "POST";

            HttpWebResponse response = (HttpWebResponse)webRequest.GetResponse();
            Stream responseStream = response.GetResponseStream();
            StreamReader reader = new StreamReader(responseStream);
            string actual = reader.ReadToEnd();

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void PUTTestMethod()
        {
            //what expected to see coming in
            string expected = "<html><body><h1>Course Response</h1><p>This is the response from the httphandler written for /module/ path</P></body></html>";

            //URI to test
            string uri = "http://fostvm.fost.plymouth.ac.uk/modules/soft338/slongville/module";

            //create web request object
            var webRequest = (HttpWebRequest)WebRequest.Create(uri);
            //set http method
            webRequest.Method = "PUT";

            HttpWebResponse response = (HttpWebResponse)webRequest.GetResponse();
            Stream responseStream = response.GetResponseStream();
            StreamReader reader = new StreamReader(responseStream);
            string actual = reader.ReadToEnd();

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void DELETETestMethod()
        {
            //what expected to see coming in
            string expected = "<html><body><h1>Course Response</h1><p>This is the response from the httphandler written for /module/ path</P></body></html>";

            //URI to test
            string uri = "http://fostvm.fost.plymouth.ac.uk/modules/soft338/slongville/module";

            //create web request object
            var webRequest = (HttpWebRequest)WebRequest.Create(uri);
            //set http method
            webRequest.Method = "DELETE";

            HttpWebResponse response = (HttpWebResponse)webRequest.GetResponse();
            Stream responseStream = response.GetResponseStream();
            StreamReader reader = new StreamReader(responseStream);
            string actual = reader.ReadToEnd();

            Assert.AreEqual(expected, actual);
        }

        //testing error codes work correctly
        [TestMethod]
        public void BadRequestTestMethod()
        {
            //what expected to see coming in
            string expected = "\r\nResponse Status Code is Bad Request - 400 and Status Description is: {0}";

            //URI to test
            string url = "http://fostvm.fost.plymouth.ac.uk/modules/soft338/slongville/student";

            //create web request object
            var myHttpWebRequest = (HttpWebRequest)WebRequest.Create(url);

            HttpWebResponse response = (HttpWebResponse)myHttpWebRequest.GetResponse();
            Stream responseStream = response.GetResponseStream();
            StreamReader reader = new StreamReader(responseStream);
            string actual = reader.ReadToEnd();

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void ForbiddenTestMethod()
        {
            //what expected to see coming in
            string expected = "\r\nResponse Status Code is Forbidden - 403 and Status Description is: {0}";

            //URI to test
            string url = "http://fostvm.fost.plymouth.ac.uk/modules/soft338/slongville/student";

            //create web request object
            var myHttpWebRequest = (HttpWebRequest)WebRequest.Create(url);

            HttpWebResponse response = (HttpWebResponse)myHttpWebRequest.GetResponse();
            Stream responseStream = response.GetResponseStream();
            StreamReader reader = new StreamReader(responseStream);
            string actual = reader.ReadToEnd();

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void NotModifiedTestMethod()
        {
            //what expected to see coming in
            string expected = "\r\nResponse Status Code is Not Modified - 304 and Status Description is: {0}";

            //URI to test
            string url = "http://fostvm.fost.plymouth.ac.uk/modules/soft338/slongville/student";

            //create web request object
            var myHttpWebRequest = (HttpWebRequest)WebRequest.Create(url);

            HttpWebResponse response = (HttpWebResponse)myHttpWebRequest.GetResponse();
            Stream responseStream = response.GetResponseStream();
            StreamReader reader = new StreamReader(responseStream);
            string actual = reader.ReadToEnd();

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void UnauthorisedTestMethod()
        {
            //what expected to see coming in
            string expected = "\r\nResponse Status Code is Unauthorised - 401 and Status Description is: {0}";

            //URI to test
            string url = "http://fostvm.fost.plymouth.ac.uk/modules/soft338/slongville/student";

            //create web request object
            var myHttpWebRequest = (HttpWebRequest)WebRequest.Create(url);

            HttpWebResponse response = (HttpWebResponse)myHttpWebRequest.GetResponse();
            Stream responseStream = response.GetResponseStream();
            StreamReader reader = new StreamReader(responseStream);
            string actual = reader.ReadToEnd();

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void NotFoundTestMethod()
        {
            //what expected to see coming in
            string expected = "\r\nResponse Status Code is Not found - 404 and Status Description is: {0}";

            //URI to test
            string url = "http://fostvm.fost.plymouth.ac.uk/modules/soft338/slongville/student";

            //create web request object
            var myHttpWebRequest = (HttpWebRequest)WebRequest.Create(url);

            HttpWebResponse response = (HttpWebResponse)myHttpWebRequest.GetResponse();
            Stream responseStream = response.GetResponseStream();
            StreamReader reader = new StreamReader(responseStream);
            string actual = reader.ReadToEnd();

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void InternalErrorTestMethod()
        {
            //what expected to see coming in
            string expected = "\r\nResponse Status Code is Internal server error - 500 and Status Description is: {0}";

            //URI to test
            string url = "http://fostvm.fost.plymouth.ac.uk/modules/soft338/slongville/student";

            //create web request object
            var myHttpWebRequest = (HttpWebRequest)WebRequest.Create(url);

            HttpWebResponse response = (HttpWebResponse)myHttpWebRequest.GetResponse();
            Stream responseStream = response.GetResponseStream();
            StreamReader reader = new StreamReader(responseStream);
            string actual = reader.ReadToEnd();

            Assert.AreEqual(expected, actual);
        }
    }
}
