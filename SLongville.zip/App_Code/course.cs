﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for course
/// </summary>
public class course
{
	    private string _CourseName; 
    public string CourseName
    {
        get { return _CourseName; }
        set { _CourseName = value; }
    }
    private string _CourseAcronym;
    public string CourseAcronym
    {
        get { return _CourseAcronym; }
        set { _CourseAcronym = value; }
    }
    
	public course(string strCourseName, string strCourseAcronym)
	{
        _CourseName = strCourseName;
        _CourseAcronym = strCourseAcronym;
	}
}