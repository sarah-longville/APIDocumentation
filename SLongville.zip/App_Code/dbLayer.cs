﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.Configuration;
using System.Data.SqlClient;

/// <summary>
/// Summary description for dbLayer
/// </summary>
public class dbLayer
{
    //this needs to be a static along with the methods that need it. 
    private static string _ConnectionString = WebConfigurationManager.ConnectionStrings["SOFT338_ConnectionString"].ConnectionString;
    public static string LastError = "";

    public dbLayer()
    {

    }
    public static List<student> getAllStudents()
    {
        //Create a new list to add students into
        List<student> students = new List<student>();
        //create a new connection using the connection string in the web.config
        SqlConnection con = new SqlConnection(_ConnectionString);
        //Create a new command object that holds the SQL statement.
        SqlCommand cmd = new SqlCommand("SELECT * FROM student", con);
        using (con)
        {
            con.Open();
            //The reader is filled using the command object which goes over the connection.
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                //this loops through all the students that are returned to create a student object and put it in the list.
                student s = new student((string)reader["firstName"], (string)reader["lastName"], (string)reader["studentNumber"], (string)reader["course"]);
                students.Add(s);
            }
        }
        return students;
    }

    public static Int32 insertNewStudent(student newStudent)
    {
        //create a new connection using the connection string in the web.config
        SqlConnection con = new SqlConnection(_ConnectionString);
        //Create a new command object that holds the SQL statement we want to run.
        SqlCommand cmd = new SqlCommand("INSERT into Student (studentNumber, lastName, firstName, course) VALUES('" + newStudent.StudentNumber + "', '"
            + newStudent.FirstName + "','" + newStudent.Course + "','" + newStudent.LastName + "'); " + "SELECT CAST(Scope_Identity() as int)", con);
        Int32 returnID = 0;
        using (con) 
        {
            try
            {
                con.Open();
                //Use the Execute Scalar part of the command object because we are inserting into the database and only
                //need to know if it worked.
                returnID = (Int32)cmd.ExecuteScalar();
            }
            catch (Exception ex)
            {
                //if there is an error save it.
                LastError = ex.Message;
            }
        }
        return returnID;
    }

    public static List<module> getAllModules()
    {
        //We create a new list to add modules into
        List<module> modules = new List<module>();
        //create a new connection using the connection string in the web.config
        SqlConnection con = new SqlConnection(_ConnectionString);
        //Create a new command object that holds the SQL statement we want to run.
        SqlCommand cmd = new SqlCommand("SELECT * FROM module", con);
        using (con)
        {
            con.Open();
            //The reader is filled using the command object which goes over the connection.
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                //this loops through all the modules that are returned to create a module object and put it in the list.
                module m = new module((string)reader["moduleCode"], (string)reader["moduleName"]);
                modules.Add(m);
            }
        }
        return modules;
    }

    public static Int32 insertNewModule(module newModule)
    {
        //create a new connection using the connection string in the web.config
        SqlConnection con = new SqlConnection(_ConnectionString);
        //Create a new command object that holds the SQL statement we want to run.
        SqlCommand cmd = new SqlCommand("INSERT into Module (moduleCode, moduleName) VALUES('" + newModule.ModuleCode + "', '"
            + newModule.ModuleName + "'); " + "SELECT CAST(Scope_Identity() as int)", con);
        Int32 returnID = 0;
        using (con)
        {
            try
            {
                con.Open();
                //Use the Execute Scalar part of the command object because we are inserting into the database and only
                //need to know if it worked.
                returnID = (Int32)cmd.ExecuteScalar();
            }
            catch (Exception ex)
            {
                //Save an error if returned.
                LastError = ex.Message;
            }
        }
        return returnID;
    }

    public static List<course> getAllCourses()
    {
        //We create a new list to add courses into
        List<course> courses = new List<course>();
        //create a new connection using the connection string in the web.config
        SqlConnection con = new SqlConnection(_ConnectionString);
        //Create a new command object that holds the SQL statement we want to run.
        SqlCommand cmd = new SqlCommand("SELECT * FROM course", con);
        using (con)
        {
            con.Open();
            //The reader is filled using the command object which goes over the connection.
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                //this loops through all the courses that are returned to create a course object and put it in the list.
                course c = new course((string)reader["courseName"], (string)reader["courseAcronym"]);
                courses.Add(c);
            }
        }
        return courses;
    }

    public static Int32 insertNewCourse(course newCourse)
    {
        //create a new connection using the connection string in the web.config
        SqlConnection con = new SqlConnection(_ConnectionString);
        //Create a new command object that holds the SQL statement we want to run.
        SqlCommand cmd = new SqlCommand("INSERT into Course (courseName, courseAcronym) VALUES('" + newCourse.CourseName+ "', '"
            + newCourse.CourseAcronym + "'); " + "SELECT CAST(Scope_Identity() as int)", con);
        Int32 returnID = 0;
        using (con)
        {
            try
            {
                con.Open();
                //Use the Execute Scalar part of the command object because we are inserting into the database and only
                //need to know if it worked.
                returnID = (Int32)cmd.ExecuteScalar();
            }
            catch (Exception ex)
            {
                //If an error is returned save it.
                LastError = ex.Message;
            }
        }
        return returnID;
    }
}