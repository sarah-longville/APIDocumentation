﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Object;
using System.MarshalByRefObject;
using System.Net.WebRequest;
using System.Net.HttpWebRequest;
using System.Collections.Specialized;
using System.Net;
using System.Text;

/// <summary>
/// Summary description for HttpHandler
/// </summary>
public class HttpHandler : IHttpHandler
{
    
	public HttpHandler()
	{

	}

    public static void GetPage (HttpContext context, string url)
    {
        
        HttpResponse Response = context.Response;
        //returns the appropriate error message if there is an issue with the request sent

            // Creates an HttpWebRequest for the specified URL. 
            HttpWebRequest myHttpWebRequest = (HttpWebRequest)WebRequest.Create(url);
            // Sends the HttpWebRequest and waits for a response.
            HttpWebResponse myHttpWebResponse = (HttpWebResponse)myHttpWebRequest.GetResponse();

            if (myHttpWebResponse.StatusCode == HttpStatusCode.BadRequest)
                Response.Write("\r\nResponse Status Code is Bad Request - 400");

            else if (myHttpWebResponse.StatusCode == HttpStatusCode.Forbidden)
                Response.Write("\r\nResponse Status Code is Forbidden - 403");

            else if(myHttpWebResponse.StatusCode == HttpStatusCode.NotModified)
                Response.Write("\r\nResponse Status Code is Not Modified - 304");

            else if(myHttpWebResponse.StatusCode == HttpStatusCode.Unauthorized)
                Response.Write("\r\nResponse Status Code is Unauthorised - 401");

            else if(myHttpWebResponse.StatusCode == HttpStatusCode.NotFound)
                Response.Write("\r\nResponse Status Code is Not Found - 404");
           
            else if (myHttpWebResponse.StatusCode == HttpStatusCode.InternalServerError)
                Response.Write("\r\nResponse Status Code is Internal Server Error - 500");

            // Releases the resources of the response.
            myHttpWebResponse.Close();
    }

    public bool IsReusable 
    { 
        get { return true; }
    }


    public void ProcessRequest(HttpContext context)
    {

        HttpRequest Request = context.Request;
        //HttpResponse Response = context.Response;
        HttpResponse Response = context.Response;

        Response.Write("This is the ProcessRequest function");

        string strPath = Request.Path.Replace("/SOFT338/slongville/", "");
        switch (strPath.ToLower())
        {
            case "student": ProcessStudents(context);
                break;
            case "module": ProcessModules(context);
                break;
            case "course": ProcessCourses(context);
                break;
                default: break;

        }
    
    }

    //students

    public void ProcessStudents(HttpContext context)
    {
        HttpResponse Response = context.Response;

        Response.Write("This is the ProcessStudents function");

        //making sure method can handle each verb - is able to retrieve data, add, delete and update 
        string httpVerb = context.Request.HttpMethod.ToLower();
        switch (httpVerb)
        {
            case "get": getAllStudents(context);
                break;
            case "post": postNewStudent(context);
                break;
            case "put": updateStudent(context);
                break;
            case "delete": removeStudent(context);
                break;
            default: break;
        }
    }

    private void removeStudent(HttpContext context)
    {
        HttpResponse Response = context.Response;

        Response.Write("This is the removeStudent function");

        throw new NotImplementedException();
    }

    private void updateStudent(HttpContext context)
    {
        HttpResponse Response = context.Response;

        Response.Write("This is the updateStudent function");

        throw new NotImplementedException();
    }

    public void postNewStudent(HttpContext context)
    {
        //object serialisation - storing an exact copy of an object so it can be recreated later. sending 
        //object by value from one domain to another
        //deserialisation - taking the object and transforming into its original form.
        DataContractJsonSerializer jsonData = new DataContractJsonSerializer(typeof(student));
        //ReadObject inputs into module object
        student s = (student)jsonData.ReadObject(context.Request.InputStream);
        //add new module to database
        Int32 StudentID = dbLayer.insertNewStudent(s);

        //the handler should be called whenever a path is called /Student/
        HttpResponse Response = context.Response;
        Response.Write("<html>");
        Response.Write("<body>");
        Response.Write("<h1>SOFT338 Response<h1>");
        Response.Write("<p>This is the response from the student path and the POST verb</p>");
        Response.Write("<p>Student Number : " + s.StudentNumber + "; First Name : " + s.FirstName + "; Last Name : " + s.LastName + "; Course : " + s.Course + ";</p>");
        Response.Write("<p>Student ID is " + StudentID.ToString() + dbLayer.LastError + "</p>");
        //HASTEOAS
        Response.Write("</body>");
        Response.Write("</html>");

    }

    //GET is the only verb that does not require some form of processing of the request data
    private void getAllStudents(HttpContext context)
    {
        HttpResponse Response = context.Response;

        Response.Write("This is the getAllStudents function");

        Stream outputStream = context.Response.OutputStream;
        //response resource is in JSON
        context.Response.ContentType = "application/json";

        //create new serialiser object - uses IEnumberable rather  than a list. Describes behaviour and 
        //compiler can defer work until later
        DataContractJsonSerializer jsonData = new DataContractJsonSerializer(typeof(IEnumerable<student>));
        IEnumerable<student> students = dbLayer.getAllStudents();
        jsonData.WriteObject(outputStream, students);
    }

    //modules

    public void ProcessModules(HttpContext context)
    {
        HttpResponse Response = context.Response;

        Response.Write("This is the ProcessModules function");

        //making sure method can handle each verb - is able to retrieve data, add, delete and update 
        string httpVerb = context.Request.HttpMethod.ToLower();
        switch (httpVerb)
        {
            case "get": getAllModules(context);
                break;
            case "post": postNewModule(context);
                break;
            case "put": updateModule(context);
                break;
            case "delete": removeModule(context);
                break;
            default: break;
        }
    }

    private void removeModule(HttpContext context)
    {
        HttpResponse Response = context.Response;

        Response.Write("This is the removeModule function");

        throw new NotImplementedException();
    }

    private void updateModule(HttpContext context)
    {
        HttpResponse Response = context.Response;

        Response.Write("This is the updateModule function");

        throw new NotImplementedException();
    }
    
    public void postNewModule(HttpContext context)
    {
        //object serialisation - storing an exact copy of an object so it can be recreated later. sending 
        //object by value from one domain to another
        //deserialisation - taking the object and transforming into its original form.
        DataContractJsonSerializer jsonData = new DataContractJsonSerializer(typeof(module));
        //ReadObject inputs into module object
        module m = (module)jsonData.ReadObject(context.Request.InputStream);
        //add new module to database
        Int32 ModuleID = dbLayer.insertNewModule(m);

        //the handler should be called whenever a path is called /Module/
        HttpResponse Response = context.Response;
        Response.Write("<html>");
        Response.Write("<body>");
        Response.Write("<h1>SOFT338 Response<h1>");
        Response.Write("<p>This is the response from the module path and the POST verb</p>");
        Response.Write("<p>Module Code : " + m.ModuleCode + "; Module Name : " + m.ModuleName + "</p>");
        Response.Write("<p>Module ID is " + ModuleID.ToString() + dbLayer.LastError + "</p>");
        //HASTEOAS
        Response.Write("/SOFT338/slongville/module");
        Response.Write("</body>");
        Response.Write("</html>");

    }

    //GET is the only verb that does not require some form of processing of the request data
    private void getAllModules(HttpContext context)
    {
        HttpResponse Response = context.Response;

        Response.Write("This is the getAllModules function");

        Stream outputStream = context.Response.OutputStream;
        //response resource is in JSON
        context.Response.ContentType = "application/json";

        //create new serialiser object - uses IEnumberable rather  than a list. Describes behaviour and 
        //compiler can defer work until later
        DataContractJsonSerializer jsonData = new DataContractJsonSerializer(typeof(IEnumerable<module>));
        IEnumerable<module> modules = dbLayer.getAllModules();
        jsonData.WriteObject(outputStream, modules);
    }

    //course
    public void ProcessCourses(HttpContext context)
    {
        HttpResponse Response = context.Response;

        Response.Write("This is the ProcessCourses function");

        //making sure method can handle each verb - is able to retrieve data, add, delete and update 
        string httpVerb = context.Request.HttpMethod.ToLower();
        switch (httpVerb)
        {
            case "get": getAllCourses(context);
                break;
            case "post": postNewCourse(context);
                break;
            case "put": updateCourse(context);
                break;
            case "delete": removeCourse(context);
                break;
            default: break;
        }
    }

    private void removeCourse(HttpContext context)
    {
        HttpResponse Response = context.Response;

        Response.Write("This is the removeCourse function");

        throw new NotImplementedException();
    }

    private void updateCourse(HttpContext context)
    {
        HttpResponse Response = context.Response;

        Response.Write("This is the updateCourse function");

        throw new NotImplementedException();
    }

    public void postNewCourse(HttpContext context)
    {

        //object serialisation - storing an exact copy of an object so it can be recreated later. sending 
        //object by value from one domain to another
        //deserialisation - taking the object and transforming into its original form.
        DataContractJsonSerializer jsonData = new DataContractJsonSerializer(typeof(course));
        //ReadObject inputs into course object
        course c = (course)jsonData.ReadObject(context.Request.InputStream);
        //add new course to database
        Int32 CourseID = dbLayer.insertNewCourse(c);

        //the handler should be called whenever a path is called /Course/
        HttpResponse Response = context.Response;
        Response.Write("<html>");
        Response.Write("<body>");
        Response.Write("<h1>SOFT338 Response<h1>");
        Response.Write("<p>This is the response from the course path and the POST verb</p>");
        Response.Write("<p>Course Name : " + c.CourseName + "; Course Acronym : " + c.CourseAcronym + "</p>");
        Response.Write("<p>Course ID is " + CourseID.ToString() + dbLayer.LastError + "</p>");
        //HASTEOAS
        Response.Write("/SOFT338/slongville/course");
        Response.Write("</body>");
        Response.Write("</html>");

    }

    //GET is the only verb that does not require some form of processing of the request data
    private void getAllCourses(HttpContext context)
    {
        HttpResponse Response = context.Response;

        Response.Write("This is the getAllCourses function");

        Stream outputStream = context.Response.OutputStream;
        //response resource is in JSON
        context.Response.ContentType = "application/json";

        //create new serialiser object - uses IEnumberable rather  than a list. Describes behaviour and 
        //compiler can defer work until later
        DataContractJsonSerializer jsonData = new DataContractJsonSerializer(typeof(IEnumerable<course>));
        IEnumerable<course> courses = dbLayer.getAllCourses();
        jsonData.WriteObject(outputStream, courses);
    }

}