﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for student
/// </summary>
public class student
{
	    private string _FirstName; 
    public string FirstName
    {
        get { return _FirstName; }
        set { _FirstName = value; }
    }

    private string _LastName;
    public string LastName
    {
        get { return _LastName; }
        set { _LastName = value; }
    }

    private string _StudentNumber;
    public string StudentNumber
    {
        get { return _StudentNumber; }
        set { _StudentNumber = value; }
    }
    private string _Course;
    public string Course
    {
        get { return _Course; }
        set { _Course = value; }
    }


	public student(string strFirstName, string strLastName, string strStudentNumber, string strCourse)
	{
        _FirstName = strFirstName;
        _LastName = strLastName;
        _StudentNumber = strStudentNumber;
        _Course = strCourse;
	}
}