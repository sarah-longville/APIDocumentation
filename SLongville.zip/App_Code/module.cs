﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for module
/// </summary>
public class module
{
	    private string _ModuleCode; 
    public string ModuleCode
    {
        get { return _ModuleCode; }
        set { _ModuleCode = value; }
    }
    private string _ModuleName;
    public string ModuleName
    {
        get { return _ModuleName; }
        set { _ModuleName = value; }
    }


	public module(string strModuleCode, string strModuleName)
	{
        _ModuleCode = strModuleCode;
        _ModuleName = strModuleName;
	}
}